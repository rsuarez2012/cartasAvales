require 'spec_helper'

describe Post do
  pending "add some examples to (or delete) #{__FILE__}"
end
